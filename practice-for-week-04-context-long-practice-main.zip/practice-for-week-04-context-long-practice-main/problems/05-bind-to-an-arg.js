function bindToAnArg(func, arg) {
  // Your code here
  return func.bind(func, arg)
}

/**************DO NOT MODIFY ANYTHING UNDER THIS  LINE*****************/
module.exports = bindToAnArg;
